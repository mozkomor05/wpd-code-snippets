export default [
    {
        caption: '_dump',
        snippet: '_dump( $1 )',
        meta: 'Symfony VarDumper',
        score: 1000001,
    },
];
