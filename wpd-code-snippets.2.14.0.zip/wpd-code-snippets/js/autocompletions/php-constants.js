export default [
    {
        caption: '__CLASS__',
        snippet: '__CLASS__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__DIR__',
        snippet: '__DIR__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__FILE__',
        snippet: '__FILE__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__FUNCTION__',
        snippet: '__FUNCTION__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__LINE__',
        snippet: '__LINE__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__METHOD__',
        snippet: '__METHOD__',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__NAMESPACE__  ',
        snippet: '__NAMESPACE__  ',
        meta: 'PHP Constant',
        score: 100002,
    },
    {
        caption: '__TRAIT__',
        snippet: '__TRAIT__',
        meta: 'PHP Constant',
        score: 100002,
    },
];
